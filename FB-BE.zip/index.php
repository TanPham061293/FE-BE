<?php
require_once 'controllers/controller.php';
$controller = new Controller();
$controller->display();
